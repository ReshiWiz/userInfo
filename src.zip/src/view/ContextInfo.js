import React from "react";
import { createContext } from "react";

const tables = [
  { id: "DJJ2q", local: "valid", controls: "Main" },
  { id: "BJW2W", local: "valid", controls: "false" },
  { id: "LNJ32", local: "host", controls: "windows" },
];

const userInfo = createContext(tables);
export default userInfo;
