// import React from "react";
// import { useContext } from "react";
// import ContextInfo from "./ContextInfo";
// export default function View() {
//   const userInfo = useContext(ContextInfo);
//   console.log(userInfo,'view');
//   return (
//     <div>
//       <h3>local</h3>
//       <li>live</li>
//     </div>
//   );
// }

import React from "react";
import { useHistory, Link } from "react-router-dom";
export default function View() {
  return (
    <div>
      <Link to={"/"}>Home page</Link>
    </div>
  );
}
