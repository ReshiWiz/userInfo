import React from "react";
import "./App.css";

import { useContext } from "react";
import ContextInfo from "./view/ContextInfo";
import Auth from "./Firebase-Auth/firebase/components/Auth";
export default function App() {
  const userInfo = useContext(ContextInfo);
  console.log(userInfo, "APP");
  return (
    <div>
      <ContextInfo.Provider value={userInfo}>
        {/* <View />
        <Form/> */}
        <Auth />
      </ContextInfo.Provider>
    </div>
  );  
}
//respective