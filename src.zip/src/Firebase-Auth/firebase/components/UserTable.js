//  import UserTable;
import Table from "react-bootstrap/Table";
import Button from "react-bootstrap/esm/Button";
import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { useNavigate } from "react-router-dom";
// import Database from "../context/Database";
import { async } from "@firebase/util";

export default function UserTable() {
  const navigate = useNavigate();
  const [updateStatus, setUpdateStatus] = useState(-1);
  const [userInfo, setUserInfo] = useState([
    {
      id: "",
      first_name: "",
      last_name: "",
      age: "",
      email: "",
      city: "",
      company_name: "",
      state: "",
      web: "",
      zip: "",
    },
  ]);

  useEffect(() => {
    fetch(
      "https://datapeace-storage.s3-us-west-2.amazonaws.com/dummy_data/users.json"
    )
      .then((res) => res.json())
      .then((data) => setUserInfo(data))

      .catch((error) => {
        console.log(`${error} oops something went wrong`);
        navigate("/waring");
      });
  }, []);

  // handle the event

  return (
    <div>
      <div style={{ margin: "4rem" }}>
        <Table striped bordered hover responsive="sm">
          <thead>
            <tr>
              {/* {userInfo.id} */}
              {/* <th>user.id</th> */}
              <th>id</th>
              <th>first_name</th>
              <th>last_name</th>
              <th>age</th>
              <th>email</th>
              <th>city</th>
              <th>zip</th>
              <th>state</th>
              <th>company_name</th>
              <th>Actions</th>
            </tr>
          </thead>

          <tbody>
            {userInfo && userInfo.length > 0
              ? userInfo.map((val) => {
                  return (
                    <tr key={val.id}>
                      <td> {val.id}</td>
                      <td>{val.first_name}</td>
                      <td>{val.last_name}</td>
                      <td>{val.age}</td>
                      <td>{val.email}</td>
                      <td>{val.city}</td>
                      <td>{val.zip}</td>
                      <td>{val.state}</td>
                      <td>{val.company_name}</td>
                      <td>
                        <Button className="m-2">Edit</Button>
                        <Button variant="danger" className="m-2">
                          Delete
                        </Button>
                      </td>
                    </tr>
                  );
                })
              : navigate("/waring")}
          </tbody>
        </Table>
      </div>
    </div>
  );
}
