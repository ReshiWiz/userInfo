import React from "react";
import { Link } from "react-router-dom";
export default function Home() {
  return (
    <div>
      <h1> home page to render</h1>

      <Link className="home-link" to={"/login"}>
        login
      </Link>
      <p>
        This application is a kind of data base of user. Who register in signup
        form
      </p>
      <p>Kindly use one spacial case (@#$%&) and one upperCase to signup </p>
      
    </div>
  );
}
