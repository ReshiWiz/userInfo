import React from "react";
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import Home from "./Home";
import SignUp from "./SignUp";
import Login from "./Login";
import UserTable from "./UserTable";
import Waring from "../context/Waring";
// import NavComp from "./parts/NavComp";
import Edit from "../context/Edit";
export default function Auth() {
  return (
    <div>
      {/* <<<---path to respective links in projects (local path)---<<  */}
      <Router>
        {/* <div className="list-unstyle">
          <ul>
            <li>
              <Link to={"/"}>Home</Link>
            </li>
            <li>
              <Link to={"signup"}>sign up</Link>
            </li>
            <li>
              <Link to={"login"}>login</Link>
            </li>
            <li>
              <Link to={"userTable"}>userInfo</Link>
            </li>
          </ul>
        </div> */}

        {/* <<<---- Local path in Router---<< */}
        {/* <NavComp /> */}
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/signup" element={<SignUp />} />
          <Route path="/login" element={<Login />} />
          <Route path="/userTable" element={<UserTable />} />
          <Route path="/waring" element={<Waring />}></Route>
          <Route path="/edit" element={<Edit/>}></Route>
          {/* <Route path="login" element ={<Login/>}</Route> */}
        </Routes>
      </Router>
    </div>
  );
}
