import React from "react";

export default function infoTable() {
  return (
    <div>
      <h3>Table info</h3>
    </div>
  );
}
