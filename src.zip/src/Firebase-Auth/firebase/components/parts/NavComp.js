// import React from "react";
// import { Link, useNavigate } from "react-router-dom";


// // import NavDropdown from "react-bootstrap/NavDropdown";

// // import Container from 'react-bootstrap/Container';
// // import Navbar from 'react-bootstrap/Navbar';

// export default function NavComp() {
//   return (
//     <div>
//       <h3>hello</h3>
//     </div>
//   );
// }
