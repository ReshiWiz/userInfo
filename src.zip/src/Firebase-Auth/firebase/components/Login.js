import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { signInWithEmailAndPassword } from "firebase/auth";
import { auth } from "../firebaseJ";
import Button from "react-bootstrap/esm/Button";

export default function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [defaultSub, setDefaultSub] = useState(false);
  //  export  const login_info_user = userInfo_login()
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    await signInWithEmailAndPassword(auth, email, password)
      .then((userInfo) => {
        const user = userInfo.user;
        console.log(user.email);
        console.log(user.uid);
        console.log(user.city);
        setPassword("");
        setEmail("");
        navigate("/userTable");
      })
      .catch((error) => {
        console.log(`{error} oops...something went wrong`);
        navigate("/waring");
      });
  };

  // popper()

  // const login = () => {
  //   alert();
  // };
  return (
    // <<<--- login page to Enter in to account---<<
    <div>
      {/* <p>{email}</p>
      <p>{password}</p> */}
      <div className="container">
        <div className="w-70 mx-auto p-4">
          <h2 className="text-center mb-4">Login Page</h2>
          <form onSubmit={handleSubmit}>
            <div className="login-form">
              <div>
                <label className="m-3" htmlFor="login">
                  Email id
                </label>
                <input
                  placeholder="Enter Your email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                />
              </div>
              <div></div>
              <div>
                <label className="m-3 " htmlFor="password">
                  Password
                </label>

                <input
                  placeholder="Enter password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                />
              </div>
              <div className="text-center">
                <Button
                  className=" m-4  "
                  type="submit"
                  variant="outline-dark "
                >
                  Login In
                </Button>
              </div>
            </div>
          </form>
        </div>
      </div>
      <p style={{ textAlign: "center" }}>
        Create a new account ? <Link to={"/signup"}>sign up</Link>
      </p>
    </div>
  );
}

// <Button
// className=" m-4 align-content-lg-center "
// type="submit"
// variant="outline-dark "
// >
// Register
// </Button>
//
//
//
