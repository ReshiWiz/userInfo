import React, { useRef, useState } from "react";
import { Link } from "react-router-dom";
import { createUserWithEmailAndPassword } from "firebase/auth";
import Button from "react-bootstrap/Button";
// import Register from "./Register";
import { BrowserRouter as Router, useNavigate } from "react-router-dom";
import { async } from "@firebase/util";

import { auth } from "../firebaseJ";

export default function SignUp() {
  const [first_name, setFirst_name] = useState("");
  const [last_name, setLast_name] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [city, setCity] = useState("");
  const [state_L, setState_L] = useState("");
  const [zip, setZip] = useState("");

  //  const [email ,password] = clearString
  const navigate = useNavigate();
  const onSubmitEvent = async (e) => {
    e.preventDefault();
    // console.log("ok");
    await createUserWithEmailAndPassword(auth, email, password, city, state_L)
      .then((details) => {
        const user = details;
        console.log(user);
        setEmail("");
        setPassword("");

        navigate("/login");
      })
      .catch((error) => {
        console.log(`${error}  oops...something went wrong `);
      });
  };
  // function allow() {
  //   alert("Thank you... for Register");
  //   navigate("/login");
  // }
  return (
    <div>
      {/* //! local login page for Registered users only page*/}
      <h3 className=" text-bg-light text-bg-danger text-center ">
        Sign up page
      </h3>
      {/* <Link to={'/'} >Go to Home</Link> */}

      <form onSubmit={onSubmitEvent} className="text-center">
        <div className="container">
          <label htmlFor="state" className="m-3 p-1">
            Enter firstName
          </label>
          <input
            style={{ textAlign: "center" }}
            placeholder="Enter your firstName"
            type="text"
            value={first_name}
            onChange={(e) => setFirst_name(e.target.value)}
          />
          <br /> <br />
          <label htmlFor="state" className="m-3 p-1">
            Enter lastName
          </label>
          <input
            style={{ textAlign: "center" }}
            placeholder="Enter your lastName"
            type="text"
            value={state_L}
            onChange={(e) => setState_L(e.target.value)}
          />
          <br /> <br />
          <label htmlFor="email" className="m-3 p-1">
            Enter Email
          </label>
          <input
            style={{ textAlign: "center" }}
            placeholder="Enter email"
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
          <br />
          <br />
          <label htmlFor="password" className="m-3 p-1">
            Enter password
          </label>
          <input
            style={{ textAlign: "center" }}
            placeholder="Enter password"
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
          <br />
          <br />
          <label htmlFor="city" className="m-3 p-1">
            Enter city
          </label>
          <input
            style={{ textAlign: "center" }}
            placeholder="Enter your city"
            type="text"
            value={city}
            onChange={(e) => setCity(e.target.value)}
          />
          <br />
          <br />
          <label htmlFor="state" className="m-3 p-1">
            Enter state
          </label>
          <input
            style={{ textAlign: "center" }}
            placeholder="Enter your state"
            type="text"
            value={state_L}
            onChange={(e) => setState_L(e.target.value)}
          />
          <br />
          <br />
          <label htmlFor="state" className="m-3 p-1">
            Enter zip code
          </label>
          <input
            style={{ textAlign: "center" }}
            placeholder="Enter your zip code"
            type="text"
            value={zip}
            onChange={(e) => setZip(e.target.value)}
          />
          <div>
            <Button
              className=" m-4 align-content-lg-center "
              type="submit"
              variant="outline-dark "
              // onClick={() => {
              //   allow();
              // }}
            >
              Register
            </Button>
          </div>
          <p>
            Already signed in ? <Link to={"/login"}>sign up</Link>
          </p>
        </div>
      </form>
    </div>
  );
}
