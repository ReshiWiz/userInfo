import React from 'react'

export default function Edit() {
  return (
    <div>
      <h3>Edit</h3>
    </div>
  )
}
