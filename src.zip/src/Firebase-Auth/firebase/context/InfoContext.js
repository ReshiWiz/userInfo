import React from "react";
import { useHistory, Link } from "react-router-dom";
export default function infoContext() {
  return (
    <div>
        
      <Link to={"/"}>Home page</Link>
    </div>
  );
}