import React from "react";
import { Link } from "react-router-dom";

export default function Waring() {
  return (
    <div>
      <h1 style={{ fontSize: "28px" }}>
        oops... Error something went wrong...!
      </h1>
      <h2>Go to home page</h2>
      <p>"place check your email/password is correct or kindly register...!"</p>
     
        <Link  to={"/"}>
          Home
        </Link>
      
    </div>
  );
}
